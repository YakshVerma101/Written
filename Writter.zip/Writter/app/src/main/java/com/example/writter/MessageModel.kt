package com.example.writter

data class MessageModel(
    val message : String,
    val role : String,
)
