package com.example.writter

class SplashScreen {


}