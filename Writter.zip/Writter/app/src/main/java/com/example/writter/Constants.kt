package com.example.writter

object Constants {
    val apiKey = "AIzaSyDrAtr-ecrpjZKFslIChQvLZ_a9wbqiDSU"
    val medapi = "4896563cc0mshe6ad4f33b13a111p170d07jsnc5c1903bfca5"
}